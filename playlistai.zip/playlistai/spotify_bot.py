import spotipy
from spotipy.oauth2 import SpotifyOAuth
from flask import Flask, request, redirect, jsonify, render_template
import webbrowser
import openai

# Configuração do Spotify (pegar do Spotify for Developers)
SPOTIPY_CLIENT_ID = "a5e579fd7f1d4b989b2761e92f0b6e38"  # Substitua pelo seu Client ID
SPOTIPY_CLIENT_SECRET = "e81e197241454a4292169f9f166a5188"  # Substitua pelo seu Client Secret
SPOTIPY_REDIRECT_URI = "http://localhost:5000/callback"
SCOPE = "playlist-modify-public playlist-modify-private user-read-private user-top-read"

# Configuração do OpenAI (ChatGPT)
openai.api_key = "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"  # Substitua pela sua chave da API OpenAI

# Inicializa o Flask
app = Flask(__name__)

# Inicializar o autenticador do Spotify
sp_oauth = SpotifyOAuth(client_id=SPOTIPY_CLIENT_ID,
                        client_secret=SPOTIPY_CLIENT_SECRET,
                        redirect_uri=SPOTIPY_REDIRECT_URI,
                        scope=SCOPE)

# Variável para armazenar o token do usuário
user_token = None


# Rota inicial para o login
@app.route('/')
def login():
    auth_url = sp_oauth.get_authorize_url()
    return f'<h1>Spotify Bot</h1><p><a href="{auth_url}">Clique aqui para fazer login no Spotify</a></p>'


# Rota de callback para obter o token após o login
@app.route('/callback')
def callback():
    global user_token
    code = request.args.get('code')  # Código retornado pelo Spotify
    user_token = sp_oauth.get_access_token(code, as_dict=False)
    return redirect('/chat')  # Redireciona para o chatbot


# Interface do Chatbot
@app.route('/chat', methods=['GET', 'POST'])
def chat():
    if not user_token:
        return redirect('/')

    if request.method == 'POST':
        user_input = request.form['user_input']  # Mensagem do usuário
        response = process_chat(user_input)  # Processa o comando do chatbot
        return jsonify(response=response)

    return render_template('chat.html')  # Exibe a interface do chatbot


# Função para processar comandos do chatbot
def process_chat(user_input):
    # Integração com o GPT para entender o comando do usuário
    gpt_response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",  # Usando o modelo correto
        messages=[
            {"role": "system", "content": "Você é um assistente que ajuda a criar playlists no Spotify."},
            {"role": "user", "content": user_input}
        ]
    )

    # Extrair a resposta gerada pelo GPT
    playlist_request = gpt_response['choices'][0]['message']['content']

    # Criar a playlist no Spotify com base na resposta
    sp = spotipy.Spotify(auth=user_token)
    user_id = sp.me()["id"]

    playlist = sp.user_playlist_create(
        user=user_id,
        name=f"Playlist: {playlist_request[:50]}",
        public=True,
        description=f"Playlist criada com base no comando: {user_input}"
    )

    # Adicionar músicas (exemplo: busca por faixas relacionadas ao comando)
    search_results = sp.search(q=playlist_request, type='track', limit=50)
    track_uris = [track['uri'] for track in search_results['tracks']['items']]
    if track_uris:
        sp.playlist_add_items(playlist_id=playlist['id'], items=track_uris)

    return f'Playlist criada com sucesso! Veja sua playlist <a href="{playlist["external_urls"]["spotify"]}" target="_blank">aqui</a>'


# Inicialização do servidor e abertura do navegador
if __name__ == '__main__':
    webbrowser.open('http://127.0.0.1:5000')
    app.run(port=5000)
